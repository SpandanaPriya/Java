package account.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import account.model.Account;



public class DaoImpl implements Dao {
	public static List<Account> L1 = new ArrayList<Account>();
	
	static{
		Account b1 = new Account("Spandana Priya","nsp",1000,400);
		Account b2= new Account("Sravya","sry",1001,300);
		Account b3= new Account("Madhu","mad",1002,200);
		Account b4= new Account("Sreeja","sri",1003,100);
		L1.add(b1);
		L1.add(b2);
		L1.add(b3);
		L1.add(b4);
		
	

	

}

	@Override
	public void createAccount(Account b) {
		L1.add(b);
		b.setList("Account created on" + getdate());
		System.out.println(b);

	}

	@Override
	public Account showBalance(int accNo) {
		Account b = new Account();
		for(Account b1 : L1) {
			if(b1.getAccNo()==accNo) {
				b=b1;
				break;
			}
		}
		// TODO Auto-generated method stub
		return b;
	}

	@Override
	public void deposit(int accNo, int amt) {
		Account b=new Account();
		for(Account b1 : L1) {
			if(b1.getAccNo()==accNo)
			{
				b=b1;
				break;
			}
		}
		// TODO Auto-generated method stub
		
      b.setBalance(b.getBalance()+amt);
      System.out.println("amount successfully deposited");
      System.out.println("your new balance :" + b.getBalance());
      b.setList("Money deposited" + amt + "on" + getdate());
      }
	@Override
	public void withDraw(int accNo, int amt) {
		Account b = new Account();
		for(Account b1 : L1) {
			if(b1.getAccNo()==accNo)
			{
				b=b1;
				break;
			}
		}
		if(b.getBalance()>amt)
		{
			b.setBalance(b.getBalance()-amt);
			System.out.println("amount successfully withdrawn");
			System.out.println("your new balance :"+ b.getBalance());
			b.setList("Money withdrawn"+ amt+"on"+getdate());
			
		}
		else
			System.out.println("you have Insufficient funds");
		
	}

	@Override
	public void fundTransfer(int accNo, int accNoto, int amt) {
		Account b = new Account();
		for(Account b1 : L1) {
			if(b1.getAccNo()==accNo)
			{
				b=b1;
				break;
			}
		}
		Account b2 = new Account();
		for(Account bt : L1) {
			if(bt.getAccNo()==accNoto)
			{
				b2 = bt;
				if(b2==null)
					System.out.println("Accontno.not found");
				break;
			}
			
		}
		if(b.getBalance()>amt)
		{
			b.setBalance(b.getBalance()-amt);
			System.out.println("amount successfully withdrawn and credited to recepient account");
			System.out.println("your new balance:"+b.getBalance());
			b2.setBalance(b2.getBalance()+amt);
			b.setList("Money transferred from your account of"+ "on"+ getdate());
		}
		else
			System.out.println("you have Insufficient funds to transfer");
	}

	@Override
	public int checkAccno(int accno) {
		boolean b=false;
		for(Account b1: L1) {
			if(b1.getAccNo()==accno)
			{
				b=true;
				return accno;
			}
		}
		if(b==false)
		{
			System.out.println("Invalid account no.\n Enter a four digit account no. ");
			
		}
		return 1;
	}

	@Override
	public int checkpass(String s) {
		boolean c=false;
		for(Account b1 : L1) {
			if(b1.getPassword().equals(s))
			{
				c=true;
				return 0;
			}
			
	}
		if(c=false)
		{
			System.out.println("Wrong Password");
		}
		return 1;
	}
			public String getdate()
			{
				DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
				Date dateobj = new Date();
				String s = df.format(dateobj);
				return s;
			}

	@Override
	public List<String> printTrans1(int accNo) {
		Account b = new Account();
		for(Account b1 : L1) {
			if(b1.getAccNo()==accNo)
			{
				b=b1;
				break;
			}
		}
		// TODO Auto-generated method stub
		return b.getList();
	}
}
package account.dao;

import java.util.List;

import account.model.Account;

public interface Dao {
	void createAccount(Account b);
	Account showBalance(int accNo);
	void deposit(int accNo,int amt);
	void withDraw(int accNo,int amt);
	void fundTransfer(int accNo,int accNoto,int amt);
	int checkAccno(int accno);
	int checkpass(String s);
	List<String> printTrans1(int accNo);
	
	
	
	

}

package account.service;
import java.util.List;
import java.util.Scanner;

import account.dao.Dao;
import account.dao.DaoImpl;
import account.model.Account;
 
public class AccountServiceImpl implements AccountService {
	private Dao dao = new DaoImpl();
	private Scanner sc = new Scanner(System.in);
	@Override
	public void createAccount() {
		Account b = new Account();
		int i;
		String name;
		System.out.println("\n Enter your details to create account :");
		do{
		System.out.println("Enter username");
		name=sc.next();
		i=b.setUserName(name);
	}
	while(i==1);
		b.setAccNo();
		b.setBalance();
		b.setPassword();
		dao.createAccount(b);
 }
	@Override
	 public Account showBalance() {
		int i,k;
		int accNo;
		String pass;
		do{
			System.out.println("Enter your Account No");
			accNo=sc.nextInt();
			i=dao.checkAccno(accNo);
		}
		while (i==1);
		do{
		System.out.println("Enter your password");
        pass=sc.next();
        k=dao.checkpass(pass);
		}
		while(k==1);
        return dao.showBalance(accNo);
		

	}
	@Override
	public void deposit() {
		System.out.println("Enter the Account No");
		int accNo = sc.nextInt();
		System.out.println("Enter Amount to be deposited");
		int amt = sc.nextInt();
		dao.deposit(accNo,amt);
		
		
		
		// TODO Auto-generated method stub
		
	}
	@Override
	public void withDraw() {
		int i,accNo,k = 0;
		String pass;
		do{
		System.out.println("Enter the Account No");
		 accNo = sc.nextInt();
		 i=dao.checkAccno(accNo);
		}
		while(k==1);
		System.out.println("Enter Amount to be deposited");
		int amt=sc.nextInt();
		dao.withDraw(accNo,amt);
		
		// TODO Auto-generated method stub
		
	}
	@Override
	public void fundTransfer() {
		int i,accNo,k;
		String pass;
		do{
		System.out.println("Enter the Account No");
		 accNo=sc.nextInt();
		 i=dao.checkAccno(accNo);
		}
		while(i==1);
		do{
			System.out.println("Enter your password");
			pass=sc.next();
			k=dao.checkpass(pass);
		}
		while(k==1);
		System.out.println("Enter the Amount to be transferred");
		int amt=sc.nextInt();
		System.out.println("Enter the Account No to be transferred");
		int accNoto
		= sc.nextInt();
		dao.fundTransfer(accNo,accNoto,amt);
		
		// TODO Auto-generated method stub

	}
	
	@Override
	public List<String> printTrans() {
		int i,k;
		int accNo;
		String pass;
		do{
			System.out.println("Enter your Account no");
			accNo=sc.nextInt();
			i=dao.checkAccno(accNo);
		}
		while(i==1);
		do{
			System.out.println("Enter your password");
			pass=sc.next();
			k=dao.checkpass(pass);
		}
		while(k==1);
	return(dao.printTrans1(accNo));
	}
	}
	

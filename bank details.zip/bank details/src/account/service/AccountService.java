package account.service;

import java.util.List;

import account.model.Account;

public interface AccountService {
    void createAccount();
	Account showBalance();
	void deposit();
	void withDraw();
	void fundTransfer();
	List<String> printTrans();
	
	
	
	

}

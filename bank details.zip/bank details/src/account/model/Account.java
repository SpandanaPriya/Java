package account.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Account {
	private String userName;
	private String password;
	private int accNo;
	private int balance;
	private static int accno=1004;
	private List<String> list=new ArrayList<String>();
	
	

	public String getUserName() {
		return userName;
	}


	@Override
	public String toString() {
		return "Account [userName=" + userName + ", accNo=" + accNo
				+ ", balance=" + balance + "]";
	}

	public int setUserName(String userName) {
		if(userName.charAt(0)>65 && userName.charAt(0)<90){
		this.userName = userName;
		return 0;
	}
		else
		{
			System.out.println("Enter first letter as capital");
			
		}
          return 1;
	}


	public String getPassword() {
		return password;
	}

private Scanner sc = new Scanner(System.in);

	public void setPassword(){
		System.out.println("set Password");
		password=sc.next();
	}
    public Account(String userName,String password,int accNo,int balance) {
    	super();
    	this.userName = userName;
    	this.password = password;
    	this.accNo = accNo;
    	this.balance = balance;
    	
    }


	public int getAccNo() {
		return accNo;
	}



	public void setAccNo() {
		accNo = ++accno;
	}



	public int getBalance() {
		return balance;
	}



	public void setBalance(int balance) {
		this.balance = balance;
	}
	public void setBalance()
	{
		balance = 0;
	}
	public Account(){
		super();
	}



	public static int getAccno() {
		return accno;
	}



	public static void setAccno(int accno) {
		Account.accno = accno;
	}



	public List<String> getList() {
		return list;
	}



	public void setList(String s)
	{  
		list.add(s);
		this.list = list;
	}

}

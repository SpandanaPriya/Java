package account.ui;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner; 

import account.service.AccountService;
import account.service.AccountServiceImpl;
public class main {
	private static AccountService service = new AccountServiceImpl();
	private static Scanner sc = new Scanner(System.in);
	public  static void main(String[] args) {
	int i=0;
		do{
		System.out.println("Pls enter your choice");
		System.out.println("1.create Account \n 2.show Balance \n 3. Deposit \n 4.Withdraw \n 5.fund Transfer \n 6.Print Transactions");
		int n=sc.nextInt();
		switch(n) {
		case 1:
			service.createAccount();
			break;
		case 2:
			System.out.println(service.showBalance());
			break;
		case 3:
			service.deposit();
			break;
		case 4:
			service.withDraw();
			break;
		case 5:
			service.fundTransfer();
			break;
		case 6:
			List<String> l1 = new ArrayList<String>();
			l1=service.printTrans();
			Iterator<String> itr = l1.iterator();
			while(itr.hasNext())
			{
				System.out.println(itr.next());
			}
		default:
		}
		System.out.println("Do you want to continue : 1.Continue \t 2.End");
		i= sc.nextInt();
		
	}
      while (i==1);
}}
